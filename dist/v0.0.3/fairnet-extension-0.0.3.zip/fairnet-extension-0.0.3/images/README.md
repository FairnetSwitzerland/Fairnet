Put all your graphic assets into this directory.
